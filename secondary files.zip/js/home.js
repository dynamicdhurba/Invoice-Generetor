    function myFunction() {
    var x = document.getElementById("myDIV");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

    $(document).ready(function(){
      $('input').click(function(){
    $(this).select();
  });
    $('select').click(function(){
    $.getJSON('fetch.php', function(data){
       console.log(data);
       $.each(data, function(i, item) {
    $('.dropup').append('<option >'+data[i].name+'</option>') ;
});
        
      });
    });

      $('#showinvoices').submit(function(e){
        e.preventDefault();
        if( $('#new').children().length<=0)
      {

  
      $.ajax({
        url : "home.php",
        type : "POST",
        data : $(this).serialize(),
        dataType: "json",
       success : function(data){
       //console.log(data);

       

             $.each(data, function(i, item) {
             //$('#new').append('<a style="text-decoration: none" href="new_final.php?mail='+data[i].in_id+'" >'+data[i].in_id+'   ->>('+data[i].datee+') </a> <br>') ;
$('#new').append('<table class="table table-striped" style="padding:10px;"><tr><th>Name</th><th>Address</th><th>Due</th></tr><tr><td>'+data[i].name+'</td><td>'+data[i].address+'</td><td>'+data[i].due+'</td></tr></table> <br>' );

});
        }
        ,
        error : function(data, status){
          $('#astatus').html(status);
        }


    });
    }
});
    });
    