  
        	//document.write(TextInsideLi);
        	//
            function check()
            {
                if (TextInsideLi!=null ) {
                   
                 $.getJSON("data/data"+TextInsideLi+".json", function(json) {  
                    //console.log(json);  
                    for (var i = 0; i < json.length; i++) {  
                        $('.screenshot').append('<img src="' + json[i].imageURL + '"/>');  
                    }  
                });
                  }

            }*/
         
        	
           
           
       