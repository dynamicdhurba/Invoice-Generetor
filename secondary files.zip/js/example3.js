function refunction()
{
  //location.reload();
window.location.replace("home.html");

}
function homefunction()
{
  location.reload();
}
  
   $(document).ready(function() {
   $('#item_submit').submit(function(e){

  e.preventDefault();
      $.ajax({
        url : "test_sixth.php",
        type : "POST",
        data : $(this).serialize(),
       // dataType: "json",
        success : function(data){
       	console.log(data);
       	alert("item saved!");
      
        },
        error:function(data)
        {
        	console.log(data);
        	$('#success').html("error");
        }
        

    });
});

   $('#save_cus').submit(function(e){

  e.preventDefault();
      $.ajax({
        url : "test_seventh.php",
        type : "POST",
        data : $(this).serialize(),
       // dataType: "json",
        success : function(data){
       alert("good job fells!");
       window.location.replace("index.php");

      
        },
        error:function(data)
        {
        	//console.log(data);
        	alert("bad job fella!");
        }
        

    });
});

   });



